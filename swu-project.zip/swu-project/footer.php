        <div id="footer_content">
            <p id="footer_logo">COMPANY | <span>COFFEE, WITH</span></p>
            <ul id="download">
                <li class='footer_logo_title'>ONLINE COMMUNITY</li>
                <li>페이스북</li>
                <li>트위터</li>
                <li>유튜브</li>
                <li>인스타그램</li>
            </ul>
            <ul id="author">
                <li class='footer_logo_title'>MADE BY</li>
                <li>웹프로그래밍</li>
                <li>2022111700 이민주</li>
            </ul>
        </div>